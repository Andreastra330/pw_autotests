rootProject.name = "pw-autotests"

